<?php
/* ======================================================== */
/* AJAX RECORD DETAILS ENDPOINT
/* ======================================================== */

// Start session for user authentication
session_start();

// Set timezone for accurate date handling
date_default_timezone_set('Asia/Colombo');

// Database configuration
$servername = "localhost";
$username = "user_kasun";
$password = "103234";
$dbname = "cbtl_cpo";
$port = 3306;

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['error' => "Connection failed: " . $conn->connect_error]));
}

// Set MySQL timezone to match PHP
$conn->query("SET time_zone = '+05:30';");

// Check if an ID is provided
if (!isset($_GET['id'])) {
    die(json_encode(['error' => 'No record ID provided']));
}

$recordId = intval($_GET['id']);

// Query to get the record by ID
$sql = "SELECT * FROM lot_history WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $recordId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die(json_encode(['error' => 'Record not found']));
}

$record = $result->fetch_assoc();

// Close connection
$conn->close();

// Remove image data to prevent popup loading issues
$images = ['picture1', 'picture2', 'picture3'];
foreach ($images as $image) {
    unset($record[$image]);
}

// Output as JSON
header('Content-Type: application/json');
echo json_encode($record);
?>