<?php
// Start session at the very top
session_start();

/* ======================================================== */
/* DATABASE CONNECTION AND SETUP
/* ======================================================== */

// Set timezone for accurate date handling
date_default_timezone_set('Asia/Colombo');

// Database configuration
$servername = "localhost";
$username = "user_kasun";
$password = "103234";
$dbname = "cbtl_cpo";
$port = 3306;

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set MySQL timezone to match PHP
$conn->query("SET time_zone = '+05:30';");

// Create users table if not exists
$createUsersTable = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    can_manage_users BOOLEAN NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if (!$conn->query($createUsersTable)) {
    die("Error creating users table: " . $conn->error);
}

// Create lotdata table if not exists
$createTableSql = "CREATE TABLE IF NOT EXISTS lotdata (
    `Lot #` VARCHAR(255) PRIMARY KEY,
    `Product Name` VARCHAR(255),
    `Customer PO#` VARCHAR(255),
    Qty DECIMAL(10,2),
    UOM VARCHAR(50),
    Status1 VARCHAR(255),
    Picture1 mediumblob,
    Picture2 mediumblob,
    Picture3 mediumblob,
    Remarks TEXT
)";
if (!$conn->query($createTableSql)) {
    die("Error creating lotdata table: " . $conn->error);
}

// Create remember_tokens table for "Remember Me" functionality
$createRememberTokensTable = "CREATE TABLE IF NOT EXISTS remember_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(64) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)";
if (!$conn->query($createRememberTokensTable)) {
    die("Error creating remember_tokens table: " . $conn->error);
}

/* ======================================================== */
/* AUTHENTICATION AND USER MANAGEMENT
/* ======================================================== */

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Login successful
            $_SESSION['user'] = $user;
            
            // Remember me functionality
            if (isset($_POST['remember_me'])) {
                // Generate token
                $token = bin2hex(random_bytes(32));
                $expires = time() + 30 * 24 * 3600; // 30 days
                
                // Store token in database
                $insertToken = $conn->prepare("INSERT INTO remember_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
                $expires_date = date('Y-m-d H:i:s', $expires);
                $insertToken->bind_param("iss", $user['id'], $token, $expires_date);
                $insertToken->execute();
                
                // Set cookie
                setcookie('remember_token', $token, $expires, '/');
            }
            
            header("Location: index.php");
            exit;
        } else {
            $loginError = "Invalid username or password";
        }
    } else {
        $loginError = "Invalid username or password";
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    // Remove remember token from database and cookie
    if (isset($_COOKIE['remember_token'])) {
        $token = $_COOKIE['remember_token'];
        $delete = $conn->prepare("DELETE FROM remember_tokens WHERE token = ?");
        $delete->bind_param("s", $token);
        $delete->execute();
        setcookie('remember_token', '', time() - 3600, '/');
    }
    
    // Destroy session
    session_destroy();
    header("Location: index.php");
    exit;
}

// Handle "Remember Me" auto-login
if (!isset($_SESSION['user']) && isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];
    $stmt = $conn->prepare("SELECT user_id, token, expires_at FROM remember_tokens WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        if (strtotime($row['expires_at']) > time()) {
            // Token is valid, log the user in
            $user_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
            $user_stmt->bind_param("i", $row['user_id']);
            $user_stmt->execute();
            $user_result = $user_stmt->get_result();
            if ($user_result->num_rows === 1) {
                $_SESSION['user'] = $user_result->fetch_assoc();
            }
        } else {
            // Token expired, delete it
            $delete = $conn->prepare("DELETE FROM remember_tokens WHERE token = ?");
            $delete->bind_param("s", $token);
            $delete->execute();
            setcookie('remember_token', '', time() - 3600, '/');
        }
    }
}

// Handle user creation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_user']) && isset($_SESSION['user']['can_manage_users']) && $_SESSION['user']['can_manage_users']) {
    $new_username = $_POST['new_username'];
    $new_fullname = $_POST['new_fullname'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    $can_manage = isset($_POST['can_manage']) ? 1 : 0;
    
    $stmt = $conn->prepare("INSERT INTO users (username, password, full_name, can_manage_users) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $new_username, $new_password, $new_fullname, $can_manage);
    
    if ($stmt->execute()) {
        $userSuccess = "User account created successfully";
    } else {
        $userError = "Error creating user: " . $stmt->error;
    }
}

/* ======================================================== */
/* FORM SUBMISSION HANDLING
/* ======================================================== */

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle record updates
    if (isset($_POST['update'])) {
        $original_customer_po = $_POST['original_customer_po'];
        $customer_po = $_POST['customer_po'];
        $location = $_POST['location'];
        $product_name = $_POST['product_name'];
        $uom = $_POST['uom'];
        $qty = $_POST['qty'];
        $wr = $_POST['wr'];
        $lot = $_POST['lot'];
        $ocean_air = $_POST['ocean_air'];
        $mfg_date = $_POST['mfg_date'];
        $best_before = $_POST['best_before'];
        $coa_status = $_POST['coa_status'];
        $sltb_approval = $_POST['sltb_approval'];
        $shipping_status = $_POST['shipping_status'];
        
        $sql = "UPDATE cpo_data SET 
                `Customer PO#` = ?,
                Location = ?,
                `Product Name` = ?,
                UOM = ?,
                Qty = ?,
                `WR #` = ?,
                `Lot #` = ?,
                `Ocean/Air` = ?,
                `Mfg Date` = ?,
                `Best Before` = ?,
                `COA STATUS` = ?,
                `SLTB Approval` = ?,
                `Shipping Status` = ?
                WHERE `Customer PO#` = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssdsssssssss", 
            $customer_po, $location, $product_name, $uom, $qty, $wr, $lot, 
            $ocean_air, $mfg_date, $best_before, $coa_status, $sltb_approval, $shipping_status, $original_customer_po);
        
        if ($stmt->execute()) {
            $success = "Record updated successfully";
        } else {
            $error = "Error updating record: " . $stmt->error;
        }
        $stmt->close();
    }
    // Handle record deletions
    elseif (isset($_POST['delete'])) {
        $customer_po = $_POST['customer_po'];
        $sql = "DELETE FROM cpo_data WHERE `Customer PO#` = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $customer_po);
        
        if ($stmt->execute()) {
            $success = "Record deleted successfully";
        } else {
            $error = "Error deleting record: " . $stmt->error;
        }
        $stmt->close();
    }
}

/* ======================================================== */
/* DATA FILTERING AND PROCESSING
/* ======================================================== */

// Get filter value if submitted
if (isset($_GET['filter_po'])) {
    $_SESSION['current_filter'] = $_GET['filter_po'];
    $filter_po = $_GET['filter_po'];
} elseif (isset($_SESSION['current_filter'])) {
    $filter_po = $_SESSION['current_filter'];
} else {
    $filter_po = '';
}

// Clear filter if requested
if (isset($_GET['clear_filter'])) {
    unset($_SESSION['current_filter']);
    $filter_po = '';
}

// Base SQL query with lot_history join
$sql = "SELECT 
            c.`Customer PO#` AS customer_po, 
            c.Location, 
            c.`Product Name` AS product_name, 
            c.UOM, 
            c.Qty, 
            c.`WR #` AS wr, 
            c.`Lot #` AS lot, 
            c.`Ocean/Air` AS ocean_air, 
            c.`Mfg Date` AS mfg_date, 
            c.`Best Before` AS best_before, 
            c.`COA STATUS` AS coa_status, 
            c.`SLTB Approval` AS sltb_approval, 
            c.`Shipping Status` AS shipping_status,
            lh.status AS lot_status
        FROM cpo_data c
        LEFT JOIN (
            SELECT l1.lot_number, l1.customer_po, l1.status 
            FROM lot_history l1
            INNER JOIN (
                SELECT lot_number, customer_po, MAX(id) as max_id
                FROM lot_history
                GROUP BY lot_number, customer_po
            ) l2 ON l1.id = l2.max_id
        ) lh ON c.`Lot #` = lh.lot_number AND c.`Customer PO#` = lh.customer_po";

// Apply filter if exists
$filtered = false;
$groupedData = [];
$poStatusFlags = [];

if (!empty($filter_po) && isset($_SESSION['user'])) {
    $filtered = true;
    $sql .= " WHERE c.`Customer PO#` LIKE ?";
    $stmt = $conn->prepare($sql);
    $search_term = "%" . $filter_po . "%";
    $stmt->bind_param("s", $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Group data by PO and check for status consistency
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $po = $row['customer_po'];
            
            if (!isset($groupedData[$po])) {
                $groupedData[$po] = [
                    'location' => $row['Location'],
                    'coa_status' => $row['coa_status'],
                    'sltb_approval' => $row['sltb_approval'],
                    'shipping_status' => $row['shipping_status'],
                    'ocean_air' => $row['ocean_air'],  // Store Ocean/Air at PO level
                    'products' => []
                ];
                $poStatusFlags[$po] = [
                    'coa_consistent' => true,
                    'sltb_consistent' => true,
                    'shipping_consistent' => true,
                    'ocean_air_consistent' => true
                ];
            }
            
            // Check for status consistency
            if ($row['coa_status'] !== $groupedData[$po]['coa_status']) {
                $poStatusFlags[$po]['coa_consistent'] = false;
            }
            if ($row['sltb_approval'] !== $groupedData[$po]['sltb_approval']) {
                $poStatusFlags[$po]['sltb_consistent'] = false;
            }
            if ($row['shipping_status'] !== $groupedData[$po]['shipping_status']) {
                $poStatusFlags[$po]['shipping_consistent'] = false;
            }
            if ($row['ocean_air'] !== $groupedData[$po]['ocean_air']) {
                $poStatusFlags[$po]['ocean_air_consistent'] = false;
            }
            
            // Add product to PO
            $groupedData[$po]['products'][] = [
                'product_name' => $row['product_name'],
                'qty' => $row['Qty'],
                'uom' => $row['UOM'],
                'wr' => $row['wr'],
                'lot' => $row['lot'],
                'ocean_air' => $row['ocean_air'],
                'mfg_date' => $row['mfg_date'],
                'best_before' => $row['best_before'],
                'coa_status' => $row['coa_status'],
                'sltb_approval' => $row['sltb_approval'],
                'shipping_status' => $row['shipping_status'],
                'lot_status' => $row['lot_status']  // New status field
            ];
        }
    }
} else {
    if (isset($_SESSION['user'])) {
        $result = $conn->query($sql);
    }
}

// Get record for editing
$edit_record = null;
if (isset($_GET['edit']) && isset($_SESSION['user'])) {
    $customer_po = $_GET['edit'];
    $sql = "SELECT * FROM cpo_data WHERE `Customer PO#` = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $customer_po);
    $stmt->execute();
    $result_edit = $stmt->get_result();
    $edit_record = $result_edit->fetch_assoc();
    $stmt->close();
}

// Get total records count
$totalRecords = 0;
if (isset($_SESSION['user'])) {
    $totalResult = $conn->query("SELECT COUNT(*) AS total FROM cpo_data");
    $totalRow = $totalResult->fetch_assoc();
    $totalRecords = $totalRow['total'];
}

// Get distinct PO numbers for autocomplete
$poNumbers = [];
if (isset($_SESSION['user'])) {
    $poResult = $conn->query("SELECT DISTINCT `Customer PO#` FROM cpo_data");
    if ($poResult->num_rows > 0) {
        while($row = $poResult->fetch_assoc()) {
            $poNumbers[] = $row['Customer PO#'];
        }
    }
}

// Function to calculate days until expiry
function calculateDaysUntilExpiry($best_before) {
    if (!$best_before || $best_before == '0000-00-00') return null;
    
    $today = new DateTime();
    $expiryDate = new DateTime($best_before);
    
    if ($expiryDate < $today) {
        return -$today->diff($expiryDate)->days; // Negative for expired
    }
    
    return $today->diff($expiryDate)->days;
}

// Function to get expiry CSS class
function getExpiryClass($days) {
    if ($days === null) return 'expiry-na';
    if ($days < 0) return 'expiry-expired';
    if ($days <= 30) return 'expiry-critical';
    if ($days <= 60) return 'expiry-warning';
    return 'expiry-ok';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CPO Data Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ======================================================== */
        /* GLOBAL STYLES
        /* ======================================================== */
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --success: #27ae60;
            --danger: #e74c3c;
            --warning: #f39c12;
            --light: #ecf0f1;
            --dark: #34495e;
            --glass: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --ocean: #1a73e8;
            --air: #9534a8ff;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a2a3a, #2c3e50);
            color: #f5f5f5;
            line-height: 1.6;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        /* ======================================================== */
        /* HEADER SECTION */
        /* ======================================================== */
        header {
            background: var(--glass);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            border: 1px solid var(--glass-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo i {
            font-size: 2.2rem;
            color: var(--secondary);
        }
        
        .logo h1 {
            font-size: 1.6rem;
            color: white;
            font-weight: 600;
        }
        
        .db-info {
            background: rgba(255, 255, 255, 0.15);
            padding: 8px 16px;
            border-radius: 20px;
            color: white;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.95rem;
        }
        
        /* ======================================================== */
        /* CARD STYLES */
        /* ======================================================== */
        .card {
            background: var(--glass);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
            overflow: hidden;
            border: 1px solid var(--glass-border);
        }
        
        .card-header {
            background: rgba(0, 0, 0, 0.2);
            color: white;
            padding: 12px 20px;
            font-size: 1.1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        /* ======================================================== */
        /* ALERT STYLES */
        /* ======================================================== */
        .alert {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.95rem;
        }
        
        .alert-success {
            background: rgba(39, 174, 96, 0.2);
            color: #d5f5e3;
            border: 1px solid rgba(39, 174, 96, 0.3);
        }
        
        .alert-danger {
            background: rgba(231, 76, 60, 0.2);
            color: #fadbd8;
            border: 1px solid rgba(231, 76, 60, 0.3);
        }
        
        /* ======================================================== */
        /* STATISTICS SECTION */
        /* ======================================================== */
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: var(--glass);
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s;
            border: 1px solid var(--glass-border);
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            background: rgba(255, 255, 255, 0.12);
        }
        
        .stat-card i {
            font-size: 2.2rem;
            margin-bottom: 12px;
            color: var(--secondary);
        }
        
        .stat-card h3 {
            font-size: 1rem;
            margin-bottom: 8px;
            color: white;
        }
        
        .stat-card .value {
            font-size: 1.8rem;
            font-weight: 700;
            color: white;
        }
        
        /* ======================================================== */
        /* FILTER SECTION */
        /* ======================================================== */
        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .filter-box {
            background: var(--glass);
            border-radius: 12px;
            padding: 15px;
            flex: 1;
            min-width: 280px;
            border: 1px solid var(--glass-border);
        }
        
        .filter-box h3 {
            color: var(--secondary);
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 1.1rem;
        }
        
        .filter-results {
            margin-top: 15px;
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.8);
        }
        
        .export-btn {
            background: var(--success);
            height: 100%;
            display: flex;
            align-items: center;
            padding: 0 18px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 0.95rem;
        }
        
        .export-btn:hover {
            background: #219653;
            transform: translateY(-2px);
        }
        
        .search-bar {
            display: flex;
            margin-bottom: 15px;
            gap: 10px;
        }
        
        .search-bar input {
            flex: 1;
            padding: 10px 16px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid var(--glass-border);
            border-radius: 25px;
            color: white;
            font-size: 0.95rem;
        }
        
        .search-bar button {
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 0.95rem;
        }
        
        /* ======================================================== */
        /* PO SUMMARY SECTION */
        /* ======================================================== */
        .po-summary-card {
            background: rgba(255, 255, 255, 0.08);
            border-radius: 10px;
            padding: 12px 15px;
            margin-bottom: 15px;
            border: 1px solid rgba(255, 255, 255, 0.15);
        }
        
        .po-summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
        }
        
        .po-summary-item {
            display: flex;
            flex-direction: column;
        }
        
        .po-summary-label {
            font-size: 0.8rem;
            color: rgba(255, 255, 255, 0.65);
            margin-bottom: 4px;
        }
        
        .po-summary-value {
            font-size: 1rem;
            font-weight: 600;
        }
        
        .ocean-air-indicator {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .ocean {
            background-color: rgba(26, 115, 232, 0.2);
            color: #8ab4f8;
            border: 1px solid rgba(26, 115, 232, 0.3);
        }
        
        .air {
            background-color: rgba(52, 168, 83, 0.2);
            color: #81c995;
            border: 1px solid rgba(52, 168, 83, 0.3);
        }
        
        .mixed {
            background-color: rgba(243, 156, 18, 0.2);
            color: #f8c471;
            border: 1px solid rgba(243, 156, 18, 0.3);
        }
        
        /* ======================================================== */
        /* TABLE STYLES */
        /* ======================================================== */
        .table-container {
            overflow-x: auto;
            border-radius: 8px;
            background: rgba(0, 0, 0, 0.1);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--glass-border);
            color: white;
            font-size: 0.95rem;
        }
        
        th {
            background: rgba(0, 0, 0, 0.2);
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        tr:nth-child(even) {
            background: rgba(255, 255, 255, 0.04);
        }
        
        tr:hover {
            background: rgba(52, 152, 219, 0.08);
        }
        
        .actions {
            display: flex;
            gap: 6px;
        }
        
        .action-btn {
            padding: 6px 10px;
            border-radius: 5px;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        
        /* ======================================================== */
        /* EXPIRY STATUS STYLES */
        /* ======================================================== */
        .expiry-cell {
            font-weight: bold;
            text-align: center;
            border-radius: 4px;
            padding: 5px 8px;
            font-size: 0.9rem;
        }
        
        .expiry-ok {
            background-color: rgba(46, 204, 113, 0.2);
            color: #7dcea0;
        }
        
        .expiry-warning {
            background-color: rgba(241, 196, 15, 0.2);
            color: #f8c471;
        }
        
        .expiry-critical {
            background-color: rgba(231, 76, 60, 0.2);
            color: #f5b7b1;
        }
        
        .expiry-expired {
            background-color: rgba(231, 76, 60, 0.3);
            color: #f1948a;
        }
        
        .expiry-na {
            background-color: rgba(149, 165, 166, 0.2);
            color: #d0d3d4;
        }
        
        /* ======================================================== */
        /* STATUS INDICATOR STYLES */
        /* ======================================================== */
        .status-inconsistent {
            position: relative;
            padding-right: 18px;
        }
        
        .status-inconsistent::after {
            content: "*";
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            color: #e74c3c;
            font-weight: bold;
        }
        
        /* ======================================================== */
        /* EDIT FORM STYLES */
        /* ======================================================== */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 15px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            color: white;
            font-size: 0.95rem;
        }
        
        input, select, textarea {
            width: 100%;
            padding: 10px 12px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid var(--glass-border);
            border-radius: 6px;
            font-size: 0.95rem;
            transition: all 0.3s;
            color: white;
        }
        
        input:focus, select:focus, textarea:focus {
            border-color: var(--secondary);
            outline: none;
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.3);
            background: rgba(255, 255, 255, 0.12);
        }
        
        /* ======================================================== */
        /* BUTTON STYLES */
        /* ======================================================== */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 20px;
            background: var(--secondary);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.95rem;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
        }
        
        .btn:hover {
            background: #2980b9;
            transform: translateY(-2px);
        }
        
        .btn-success {
            background: var(--success);
        }
        
        .btn-success:hover {
            background: #219653;
        }
        
        .btn-danger {
            background: var(--danger);
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .btn-group {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }
        
        /* ======================================================== */
        /* MISC STYLES */
        /* ======================================================== */
        .no-records {
            text-align: center;
            padding: 40px;
            color: rgba(255, 255, 255, 0.5);
            font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
                gap: 12px;
            }
            
            .logo h1 {
                font-size: 1.5rem;
            }
            
            .db-info {
                font-size: 0.9rem;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .btn-group {
                flex-direction: column;
            }
            
            .filter-section {
                flex-direction: column;
            }
            
            .export-btn {
                width: 100%;
                justify-content: center;
                padding: 12px;
            }
            
            .po-summary-grid {
                grid-template-columns: 1fr 1fr;
            }
        }
        
        footer {
            text-align: center;
            margin-top: 25px;
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.85rem;
            padding: 15px;
        }
        
        .autocomplete-items {
            position: absolute;
            border: 1px solid #d4d4d4;
            border-bottom: none;
            border-top: none;
            z-index: 99;
            top: 100%;
            left: 0;
            right: 0;
            max-height: 200px;
            overflow-y: auto;
            border-radius: 0 0 8px 8px;
        }
        
        .autocomplete-items div {
            padding: 8px;
            cursor: pointer;
            background-color: rgba(44, 62, 80, 0.95);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 0.9rem;
        }
        
        .autocomplete-items div:hover {
            background-color: var(--secondary);
        }
        
        .autocomplete-active {
            background-color: var(--secondary) !important;
            color: #ffffff;
        }
        
        .autocomplete-container {
            position: relative;
            flex: 1;
        }
        
        .clear-btn {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: #ccc;
            cursor: pointer;
            z-index: 10;
            font-size: 0.9rem;
        }
        
        .clear-btn:hover {
            color: white;
        }
        
        /* ======================================================== */
        /* LOGIN PAGE STYLES */
        /* ======================================================== */
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 25px;
        }
        
        .login-header i {
            font-size: 3rem;
            color: #3498db;
            margin-bottom: 15px;
        }
        
        .login-header h1 {
            color: white;
            font-size: 1.8rem;
        }
        
        .login-form-group {
            margin-bottom: 20px;
        }
        
        .login-form-group label {
            display: block;
            margin-bottom: 8px;
            color: rgba(255, 255, 255, 0.8);
            font-weight: 600;
        }
        
        .login-form-group input {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            color: white;
            font-size: 1rem;
        }
        
        .login-form-group input:focus {
            outline: none;
            border-color: #3498db;
        }
        
        .remember-me {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            color: rgba(255, 255, 255, 0.8);
        }
        
        .remember-me input {
            margin-right: 8px;
        }
        
        .btn-login {
            width: 100%;
            padding: 12px;
            background: #3498db;
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn-login:hover {
            background: #2980b9;
        }
        
        .error {
            color: #e74c3c;
            text-align: center;
            margin-bottom: 15px;
            font-weight: 500;
        }
        
        /* ======================================================== */
        /* USER INFO SECTION */
        /* ======================================================== */
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-welcome {
            background: rgba(255, 255, 255, 0.15);
            padding: 8px 16px;
            border-radius: 20px;
            color: white;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .user-actions {
            display: flex;
            gap: 10px;
        }
        
        .user-btn {
            padding: 8px 15px;
            border-radius: 6px;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
        }
        
        /* ======================================================== */
        /* USER MODAL STYLES */
        /* ======================================================== */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .modal-content {
            background: #2c3e50;
            padding: 25px;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .close-modal {
            background: none;
            border: none;
            color: #ccc;
            font-size: 1.5rem;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php if (!isset($_SESSION['user'])): ?>
        <!-- Login Form -->
        <div class="login-container">
            <div class="login-header">
                <i class="fas fa-lock"></i>
                <h1>CPO Data System Login</h1>
            </div>
            <?php if (isset($loginError)): ?>
                <div class="error"><?php echo $loginError; ?></div>
            <?php endif; ?>
            <form method="post">
                <div class="login-form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required autofocus>
                </div>
                <div class="login-form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
            
                <button type="submit" name="login" class="btn-login">Login</button>
            </form>
        </div>
    <?php else: ?>
        <div class="container">
            <!-- ======================================================== -->
            <!-- HEADER SECTION WITH USER INFO -->
            <!-- ======================================================== -->
            <header>
                <div class="logo">
                    <i class="fas fa-database"></i>
                    <h1>CPO Data Management System (QAD)</h1>
                </div>
                <div class="user-info">
                    <div class="user-welcome">
                        <i class="fas fa-user"></i>
                        <span>Welcome, <?php echo htmlspecialchars($_SESSION['user']['full_name']); ?></span>
                    </div>
                    <div class="user-actions">
                        <?php if ($_SESSION['user']['can_manage_users']): ?>
                            <a href="#" class="btn user-btn" onclick="openUserModal()">
                                <i class="fas fa-user-plus"></i> Create User
                            </a>
                        <?php endif; ?>
                        <a href="?logout" class="btn btn-danger user-btn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </header>
            
            <!-- ======================================================== -->
            <!-- ALERT MESSAGES -->
            <!-- ======================================================== -->
            <?php if (isset($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <!-- ======================================================== -->
            <!-- STATISTICS SECTION -->
            <!-- ======================================================== -->
            <div class="stats">
                <div class="stat-card">
                    <i class="fas fa-boxes"></i>
                    <h3>Total Records</h3>
                    <div class="value"><?php echo $totalRecords; ?></div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-filter"></i>
                    <h3>Filtered Records</h3>
                    <div class="value"><?php 
                        if ($filtered && !empty($groupedData)) {
                            $count = 0;
                            foreach ($groupedData as $po => $data) {
                                $count += count($data['products']);
                            }
                            echo $count;
                        } else {
                            echo '0';
                        }
                    ?></div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-plug"></i>
                    <h3>Database Status</h3>
                    <div class="value">Connected</div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-sync-alt"></i>
                    <h3>Last Update</h3>
                    <div class="value"><?php echo date('H:i:s'); ?></div>
                </div>
            </div>
            
            <!-- ======================================================== -->
            <!-- FILTER SECTION -->
            <!-- ======================================================== -->
            <div class="filter-section">
                <div class="filter-box">
                    <h3><i class="fas fa-search"></i> Filter by Customer PO#</h3>
                    <form method="GET" action="" id="filterForm">
                        <div class="search-bar">
                            <div class="autocomplete-container">
                                <input type="text" id="filterInput" name="filter_po" 
                                       placeholder="Start typing PO number..." 
                                       value="<?php echo htmlspecialchars($filter_po); ?>"
                                       autocomplete="off">
                                <?php if ($filter_po): ?>
                                    <button type="button" class="clear-btn" onclick="clearFilter()">
                                        <i class="fas fa-times"></i>
                                    </button>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn">
                                <i class="fas fa-filter"></i> Apply
                            </button>
                        </div>
                        <div class="filter-results">
                            <?php if (!empty($filter_po)): ?>
                                Showing results for: <strong><?php echo htmlspecialchars($filter_po); ?></strong>
                            <?php else: ?>
                                Enter a Customer PO# to view records
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
                <div class="export-btn" onclick="exportData()">
                    <i class="fas fa-file-export"></i> Export Data
                </div>
            </div>
            
            <!-- ======================================================== -->
            <!-- EDIT FORM SECTION -->
            <!-- ======================================================== -->
            <?php if ($edit_record): ?>
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-edit"></i> Edit Record: <?php echo $edit_record['Customer PO#']; ?>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <input type="hidden" name="original_customer_po" value="<?php echo $edit_record['Customer PO#']; ?>">
                        
                        <div class="form-grid">
                            <!-- Customer PO Information -->
                            <div class="form-group">
                                <label for="customer_po"><i class="fas fa-barcode"></i> Customer PO#</label>
                                <input type="text" id="customer_po" name="customer_po" required 
                                    value="<?php echo $edit_record['Customer PO#']; ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="location"><i class="fas fa-map-marker-alt"></i> Location</label>
                                <input type="text" id="location" name="location" required
                                    value="<?php echo $edit_record['Location']; ?>">
                            </div>
                            
                            <!-- Product Information -->
                            <div class="form-group">
                                <label for="product_name"><i class="fas fa-cube"></i> Product Name</label>
                                <input type="text" id="product_name" name="product_name" required
                                    value="<?php echo $edit_record['Product Name']; ?>">
                            </div>
                            
                            <!-- Ocean/Air Information -->
                            <div class="form-group">
                                <label for="ocean_air"><i class="fas fa-ship"></i> Ocean/Air</label>
                                <select id="ocean_air" name="ocean_air" class="ocean-air-select">
                                    <option value="Ocean" <?php echo ($edit_record['Ocean/Air'] == 'Ocean') ? 'selected' : ''; ?>>Ocean</option>
                                    <option value="Air" <?php echo ($edit_record['Ocean/Air'] == 'Air') ? 'selected' : ''; ?>>Air</option>
                                </select>
                            </div>
                            
                            <!-- Quantity Information -->
                            <div class="form-group">
                                <label for="uom"><i class="fas fa-balance-scale"></i> UOM</label>
                                <input type="text" id="uom" name="uom" 
                                    value="<?php echo $edit_record['UOM']; ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="qty"><i class="fas fa-calculator"></i> Quantity</label>
                                <input type="number" id="qty" name="qty" step="0.01" 
                                    value="<?php echo $edit_record['Qty']; ?>">
                            </div>
                            
                            <!-- Reference Numbers -->
                            <div class="form-group">
                                <label for="wr"><i class="fas fa-file-alt"></i> WR #</label>
                                <input type="text" id="wr" name="wr" 
                                    value="<?php echo $edit_record['WR #']; ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="lot"><i class="fas fa-tag"></i> Lot #</label>
                                <input type="text" id="lot" name="lot" 
                                    value="<?php echo $edit_record['Lot #']; ?>">
                            </div>
                            
                            <!-- Date Information -->
                            <div class="form-group">
                                <label for="mfg_date"><i class="fas fa-calendar-alt"></i> Mfg Date</label>
                                <input type="date" id="mfg_date" name="mfg_date" 
                                    value="<?php echo $edit_record['Mfg Date']; ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="best_before"><i class="fas fa-hourglass-half"></i> Best Before</label>
                                <input type="date" id="best_before" name="best_before" 
                                    value="<?php echo $edit_record['Best Before']; ?>">
                            </div>
                            
                            <!-- Status Information -->
                            <div class="form-group">
                                <label for="coa_status"><i class="fas fa-certificate"></i> COA Status</label>
                                <select id="coa_status" name="coa_status">
                                    <option value="Pending" <?php echo ($edit_record['COA STATUS'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Approved" <?php echo ($edit_record['COA STATUS'] == 'Approved') ? 'selected' : ''; ?>>Approved</option>
                                    <option value="Rejected" <?php echo ($edit_record['COA STATUS'] == 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="sltb_approval"><i class="fas fa-check-circle"></i> SLTB Approval</label>
                                <select id="sltb_approval" name="sltb_approval">
                                    <option value="Pending" <?php echo ($edit_record['SLTB Approval'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Approved" <?php echo ($edit_record['SLTB Approval'] == 'Approved') ? 'selected' : ''; ?>>Approved</option>
                                    <option value="Rejected" <?php echo ($edit_record['SLTB Approval'] == 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="shipping_status"><i class="fas fa-truck"></i> Shipping Status</label>
                                <select id="shipping_status" name="shipping_status">
                                    <option value="Pending" <?php echo ($edit_record['Shipping Status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="In Transit" <?php echo ($edit_record['Shipping Status'] == 'In Transit') ? 'selected' : ''; ?>>In Transit</option>
                                    <option value="Delivered" <?php echo ($edit_record['Shipping Status'] == 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                                </select>
                            </div>
                        </div>
                        
                        <!-- Form Actions -->
                        <div class="btn-group">
                            <button type="submit" name="update" class="btn btn-success">
                                <i class="fas fa-save"></i> Update Record
                            </button>
                            <a href="index.php" class="btn">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>

            <!-- ======================================================== -->
            <!-- DATA TABLE SECTION -->
            <!-- ======================================================== -->
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-table"></i> CPO Data Records
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <?php if (!empty($filter_po) && !empty($groupedData)): ?>
                            <?php foreach ($groupedData as $po => $data): ?>
                                <?php 
                                    $statusClass = '';
                                    $inconsistent = false;
                                    if (!$poStatusFlags[$po]['coa_consistent'] || 
                                        !$poStatusFlags[$po]['sltb_consistent'] || 
                                        !$poStatusFlags[$po]['ocean_air_consistent']) {
                                        $statusClass = 'status-inconsistent';
                                        $inconsistent = true;
                                    }

                                    // Determine Ocean/Air display
                                    $oceanAirClass = strtolower($data['ocean_air']);
                                    $oceanAirText = $data['ocean_air'];
                                    if (!$poStatusFlags[$po]['ocean_air_consistent']) {
                                        $oceanAirClass = 'mixed';
                                        $oceanAirText = 'Mixed';
                                    }
                                ?>
                                
                                <!-- PO Summary Card - Core Data -->
                                <div class="po-summary-card">
                                    <div class="po-summary-grid">
                                        <div class="po-summary-item">
                                            <span class="po-summary-label">PO #</span>
                                            <span class="po-summary-value"><?= htmlspecialchars($po) ?></span>
                                        </div>
                                        <div class="po-summary-item">
                                            <span class="po-summary-label">Location</span>
                                            <span class="po-summary-value"><?= htmlspecialchars($data['location']) ?></span>
                                        </div>
                                        <div class="po-summary-item">
                                            <span class="po-summary-label">COA Status</span>
                                            <span class="po-summary-value"><?= htmlspecialchars($data['coa_status']) ?></span>
                                        </div>
                                        <div class="po-summary-item">
                                            <span class="po-summary-label">SLTB Approval</span>
                                            <span class="po-summary-value"><?= htmlspecialchars($data['sltb_approval']) ?></span>
                                        </div>
                                        <div class="po-summary-item">
                                            <span class="po-summary-label">Transport</span>
                                            <span class="ocean-air-indicator <?= $oceanAirClass ?>">
                                                <i class="fas <?= $oceanAirClass === 'air' ? 'fa-plane' : 'fa-ship' ?>"></i>
                                                <?= $oceanAirText ?>
                                            </span>
                                        </div>
                                    </div>

                                    <?php if ($inconsistent): ?>
                                        <div style="margin-top: 10px; font-size: 0.8rem; color: #7c7a7aff;">
                                            <i class="fas fa-exclamation-triangle"></i> Status values vary between products
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Shipping Status Card -->
                                <div class="po-summary-card">
                                    <div class="po-summary-grid">
                                        <div class="po-summary-item">
                                            <span class="po-summary-label">Shipping & Special Notes</span>
                                            <span class="po-summary-value"><?= htmlspecialchars($data['shipping_status']) ?></span>
                                        </div>
                                    </div>

                                    <?php if (!$poStatusFlags[$po]['shipping_consistent']): ?>
                                        <div style="margin-top: 10px; font-size: 0.9rem; color: #e74c3c;">
                                            
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Products Table -->
                                <table id="dataTable">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Qty</th>
                                            <th>UOM</th>
                                            <th>WR #</th>
                                            <th>Lot #</th>
                                            <th>Mfg Date</th>
                                            <th>Best Before</th>
                                            <th>Expiry Status</th>
                                            <!-- NEW STATUS COLUMN HEADER -->
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($data['products'] as $product): 
                                            $daysLeft = calculateDaysUntilExpiry($product['best_before']);
                                            $expiryClass = getExpiryClass($daysLeft);
                                            $daysText = '';
                                            
                                            if ($daysLeft === null) {
                                                $daysText = 'N/A';
                                            } elseif ($daysLeft < 0) {
                                                $daysText = abs($daysLeft) . ' days expired';
                                            } else {
                                                $daysText = $daysLeft . ' days left';
                                            }
                                        ?>
                                            <tr>
                                                <td><?= htmlspecialchars($product['product_name']) ?></td>
                                                <td><?= htmlspecialchars($product['qty']) ?></td>
                                                <td><?= htmlspecialchars($product['uom']) ?></td>
                                                <td><?= htmlspecialchars($product['wr']) ?></td>
                                                <td>
                                                    <a href="lot_details.php?lot=<?= urlencode($product['lot']) ?>&product_name=<?= urlencode($product['product_name']) ?>&customer_po=<?= urlencode($po) ?>&qty=<?= urlencode($product['qty']) ?>&uom=<?= urlencode($product['uom']) ?>" 
                                                       style="color: #3498db; text-decoration: none;">
                                                        <?= htmlspecialchars($product['lot']) ?>
                                                    </a>
                                                </td>
                                                <td><?= htmlspecialchars($product['mfg_date']) ?></td>
                                                <td><?= htmlspecialchars($product['best_before']) ?></td>
                                                <td class="expiry-cell <?= $expiryClass ?>"><?= $daysText ?></td>
                                                <!-- NEW STATUS COLUMN DATA -->
                                                <td>
                                                    <?= !empty($product['lot_status']) ? 
                                                        htmlspecialchars($product['lot_status']) : 
                                                        'Yet to Check' ?>
                                                </td>
                                                <td class="actions">
                                                    <a href="?edit=<?= urlencode($po) ?>#edit" class="btn action-btn">
                                                        <i class="fas fa-edit"></i> 
                                                    </a>
                                                    <form method="post" style="display:inline;" 
                                                          onsubmit="return confirm('Are you sure you want to delete this record?');">
                                                        <input type="hidden" name="customer_po" value="<?= htmlspecialchars($po) ?>">
                                                        <button type="submit" name="delete" class="btn btn-danger action-btn">
                                                            <i class="fas fa-trash"></i> 
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php endforeach; ?>
                        <?php elseif (!empty($filter_po) && empty($groupedData)): ?>
                            <div class="no-records">
                                <i class="fas fa-search fa-3x" style="margin-bottom: 20px;"></i>
                                <h3>No records found</h3>
                                <p>No records match your filter criteria</p>
                            </div>
                        <?php else: ?>
                            <div class="no-records">
                                <i class="fas fa-filter fa-3x" style="margin-bottom: 20px;"></i>
                                <h3>No records to display</h3>
                                <p>Please select a Customer PO# and apply filter to view records</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- ======================================================== -->
            <!-- USER MODAL -->
            <!-- ======================================================== -->
            <div id="userModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>Create New User</h2>
                        <button class="close-modal" onclick="closeUserModal()">&times;</button>
                    </div>
                    <?php if (isset($userSuccess)): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> <?php echo $userSuccess; ?>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($userError)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $userError; ?>
                        </div>
                    <?php endif; ?>
                    <form method="post">
                        <div class="form-group">
                            <label for="new_username"><i class="fas fa-user"></i> Username</label>
                            <input type="text" id="new_username" name="new_username" required>
                        </div>
                        <div class="form-group">
                            <label for="new_fullname"><i class="fas fa-id-card"></i> Full Name</label>
                            <input type="text" id="new_fullname" name="new_fullname" required>
                        </div>
                        <div class="form-group">
                            <label for="new_password"><i class="fas fa-key"></i> Password</label>
                            <input type="password" id="new_password" name="new_password" required>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="can_manage" value="1">
                                Can manage users
                            </label>
                        </div>
                        <div class="btn-group">
                            <button type="submit" name="create_user" class="btn btn-success">
                                <i class="fas fa-save"></i> Create User
                            </button>
                            <button type="button" class="btn" onclick="closeUserModal()">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- ======================================================== -->
            <!-- FOOTER SECTION -->
            <!-- ======================================================== -->
            <footer>
               (kiz) CPO Data Management System &copy; <?php echo date('Y'); ?>
            </footer>
        </div>
    <?php endif; ?>
    
    <script>
        /* ======================================================== */
        /* AUTOCOMPLETE FUNCTIONALITY
        /* ======================================================== */
        // PO numbers from PHP for autocomplete
        const poNumbers = <?php echo json_encode($poNumbers); ?>;
        
        // Initialize autocomplete
        function autocomplete(inp, arr) {
            let currentFocus;
            
            inp.addEventListener("input", function(e) {
                let a, b, i, val = this.value;
                closeAllLists();
                if (!val) { return false; }
                currentFocus = -1;
                
                a = document.createElement("DIV");
                a.setAttribute("id", this.id + "autocomplete-list");
                a.setAttribute("class", "autocomplete-items");
                this.parentNode.appendChild(a);
                
                for (i = 0; i < arr.length; i++) {
                    if (arr[i].substr(0, val.length).toUpperCase() === val.toUpperCase()) {
                        b = document.createElement("DIV");
                        b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                        b.innerHTML += arr[i].substr(val.length);
                        b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                        b.addEventListener("click", function(e) {
                            inp.value = this.getElementsByTagName("input")[0].value;
                            closeAllLists();
                            document.getElementById('filterForm').submit();
                        });
                        a.appendChild(b);
                    }
                }
                
                // Show clear button when there's text
                if (val && !document.querySelector('.clear-btn')) {
                    const clearBtn = document.createElement("button");
                    clearBtn.className = "clear-btn";
                    clearBtn.innerHTML = '<i class="fas fa-times"></i>';
                    clearBtn.onclick = clearFilter;
                    this.parentNode.appendChild(clearBtn);
                }
            });
            
            inp.addEventListener("keydown", function(e) {
                let x = document.getElementById(this.id + "autocomplete-list");
                if (x) x = x.getElementsByTagName("div");
                if (e.keyCode == 40) { // Down arrow
                    currentFocus++;
                    addActive(x);
                } else if (e.keyCode == 38) { // Up arrow
                    currentFocus--;
                    addActive(x);
                } else if (e.keyCode == 13) { // Enter
                    e.preventDefault();
                    if (currentFocus > -1) {
                        if (x) x[currentFocus].click();
                    } else {
                        document.getElementById('filterForm').submit();
                    }
                }
            });
            
            function addActive(x) {
                if (!x) return false;
                removeActive(x);
                if (currentFocus >= x.length) currentFocus = 0;
                if (currentFocus < 0) currentFocus = (x.length - 1);
                x[currentFocus].classList.add("autocomplete-active");
            }
            
            function removeActive(x) {
                for (let i = 0; i < x.length; i++) {
                    x[i].classList.remove("autocomplete-active");
                }
            }
            
            function closeAllLists(elmnt) {
                const x = document.getElementsByClassName("autocomplete-items");
                for (let i = 0; i < x.length; i++) {
                    if (elmnt != x[i] && elmnt != inp) {
                        x[i].parentNode.removeChild(x[i]);
                    }
                }
            }
            
            document.addEventListener("click", function(e) {
                closeAllLists(e.target);
            });
        }
        
        // Initialize autocomplete
        autocomplete(document.getElementById("filterInput"), poNumbers);
        
        /* ======================================================== */
        /* UTILITY FUNCTIONS
        /* ======================================================== */
        // Clear filter function
        function clearFilter() {
            window.location.href = 'index.php?clear_filter=true';
        }
        
        // Export data function
        function exportData() {
            alert("Data export would be implemented here. In a real application, this would generate a CSV or Excel file.");
        }
        
        // Automatically focus on filter input
        document.addEventListener('DOMContentLoaded', function() {
            const filterInput = document.getElementById('filterInput');
            if (filterInput) {
                filterInput.focus();
            }
            
            // Highlight Ocean/Air select based on value
            document.querySelectorAll('.ocean-air-select').forEach(select => {
                select.addEventListener('change', function() {
                    this.className = 'ocean-air-select';
                    this.classList.add(this.value.toLowerCase());
                });
                
                // Set initial class
                select.classList.add(select.value.toLowerCase());
            });
        });
        
        /* ======================================================== */
        /* USER MODAL FUNCTIONS
        /* ======================================================== */
        function openUserModal() {
            document.getElementById('userModal').style.display = 'flex';
        }
        
        function closeUserModal() {
            document.getElementById('userModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('userModal');
            if (event.target === modal) {
                closeUserModal();
            }
        });
    </script>
</body>
</html>

<?php
// Close database connection
$conn->close();
?>