<?php
/* ======================================================== */
/* DATABASE CONNECTION AND SETUP
/* ======================================================== */

// Start session for user authentication
session_start();

// Set timezone for accurate date handling
date_default_timezone_set('Asia/Colombo');

// Updated database configuration to match index.php
$servername = "localhost";
$username = "user_kasun";
$password = "103234";
$dbname = "cbtl_cpo";
$port = 3306;

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set MySQL timezone to match PHP
$conn->query("SET time_zone = '+05:30';");

// Try to increase max allowed packet size
@$conn->query("SET GLOBAL max_allowed_packet=67108864;"); // 64MB

// Create only history table with unique constraint
$createLotHistoryTable = "CREATE TABLE IF NOT EXISTS lot_history (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `lot_number` VARCHAR(50) NOT NULL,
    `product_name` VARCHAR(255) NOT NULL,
    `customer_po` VARCHAR(255) NOT NULL,
    `qty` VARCHAR(50) NOT NULL,
    `uom` VARCHAR(50) NOT NULL,
    `status` VARCHAR(50) NOT NULL,
    `remarks` TEXT,
    `picture1` LONGBLOB,
    `picture2` LONGBLOB,
    `picture3` LONGBLOB,
    `updated_by` VARCHAR(255) NOT NULL,
    `updated_at` DATETIME NOT NULL,
    UNIQUE KEY `unique_status_entry` (`lot_number`, `customer_po`, `status`)
)";

// Execute table creation
if (!$conn->query($createLotHistoryTable)) {
    die("Error creating lot_history table: " . $conn->error);
}

// Get parameters from URL
$lot = isset($_GET['lot']) ? $_GET['lot'] : '';
$product_name = isset($_GET['product_name']) ? $_GET['product_name'] : '';
$customer_po = isset($_GET['customer_po']) ? $_GET['customer_po'] : '';
$qty = isset($_GET['qty']) ? $_GET['qty'] : '';
$uom = isset($_GET['uom']) ? $_GET['uom'] : '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if user confirmed the status change
    if (!isset($_POST['confirm_status_change']) || $_POST['confirm_status_change'] !== 'yes') {
        $_SESSION['error'] = "Please confirm the status change";
        header("Location: lot_details.php?lot=" . urlencode($lot) . 
               "&product_name=" . urlencode($product_name) . 
               "&customer_po=" . urlencode($customer_po) . 
               "&qty=" . urlencode($qty) . 
               "&uom=" . urlencode($uom));
        exit;
    }

    $lot = $_POST['lot'];
    $product_name = $_POST['product_name'];
    $customer_po = $_POST['customer_po'];
    $qty = $_POST['qty'];
    $uom = $_POST['uom'];
    $status = $_POST['status'];
    $remarks = $_POST['remarks'];
    
    // Format remarks with timestamp and username
    $currentUser = isset($_SESSION['user']['full_name']) ? $_SESSION['user']['full_name'] : 'Unknown User';
    $timestamp = date('Y-m-d H:i:s');
    
    // Include status in remarks
    $formattedRemarks = "[$timestamp] $currentUser: Status changed to '$status'. $remarks\n";
    
    // Initialize image variables
    $image1 = null;
    $image2 = null;
    $image3 = null;
    
    function processImageUpload($fieldName) {
        if (isset($_FILES[$fieldName])) {
            if ($_FILES[$fieldName]['error'] === UPLOAD_ERR_OK) {
                // Check file size (max 8MB)
                if ($_FILES[$fieldName]['size'] > 8388608) {
                    $_SESSION['error'] = "Image too large (max 8MB)";
                    return null;
                }
                
                $tmpFilePath = $_FILES[$fieldName]['tmp_name'];
                // Check if the file is an image
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($tmpFilePath);
                $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                if (in_array($mime, $allowed)) {
                    return file_get_contents($tmpFilePath);
                } else {
                    $_SESSION['error'] = "Invalid image format. Only JPG, PNG, GIF, and WEBP are allowed.";
                }
            } elseif ($_FILES[$fieldName]['error'] !== UPLOAD_ERR_NO_FILE) {
                $_SESSION['error'] = "Error uploading file: " . $_FILES[$fieldName]['error'];
            }
        }
        return null;
    }

    $image1 = processImageUpload('image1');
    $image2 = processImageUpload('image2');
    $image3 = processImageUpload('image3');
    
    // Check if we have any errors
    if (isset($_SESSION['error'])) {
        // Redirect back with error message
        header("Location: lot_details.php?lot=" . urlencode($lot) . 
               "&product_name=" . urlencode($product_name) . 
               "&customer_po=" . urlencode($customer_po) . 
               "&qty=" . urlencode($qty) . 
               "&uom=" . urlencode($uom));
        exit;
    }
    
    // Check connection status and reconnect if needed
    if (!$conn->ping()) {
        $conn = new mysqli($servername, $username, $password, $dbname, $port);
    }
    
    // Check if identical status record exists for this lot+PO combination
    $checkSql = "SELECT id FROM lot_history 
                 WHERE lot_number = ? 
                 AND customer_po = ? 
                 AND status = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("sss", $lot, $customer_po, $status);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Status data already available for this combination";
        // Redirect back with error message
        header("Location: lot_details.php?lot=" . urlencode($lot) . 
               "&product_name=" . urlencode($product_name) . 
               "&customer_po=" . urlencode($customer_po) . 
               "&qty=" . urlencode($qty) . 
               "&uom=" . urlencode($uom));
        exit;
    }
    
    // Insert new history record
    $insertSql = "INSERT INTO lot_history (
        `lot_number`, 
        `product_name`, 
        `customer_po`, 
        `qty`, 
        `uom`, 
        `status`, 
        `remarks`,
        `picture1`,
        `picture2`,
        `picture3`,
        `updated_by`,
        `updated_at`
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $insertStmt = $conn->prepare($insertSql);
    $insertStmt->bind_param(
        "ssssssssssss", 
        $lot, 
        $product_name, 
        $customer_po, 
        $qty, 
        $uom, 
        $status, 
        $formattedRemarks,
        $image1,
        $image2,
        $image3,
        $currentUser,
        $timestamp
    );
    $insertStmt->execute();
    $insertStmt->close();
    
    // Set flag to reset form after redirect
    $_SESSION['reset_form'] = true;
    
    // Redirect to prevent form resubmission
    header("Location: lot_details.php?lot=" . urlencode($lot) . 
           "&product_name=" . urlencode($product_name) . 
           "&customer_po=" . urlencode($customer_po) . 
           "&qty=" . urlencode($qty) . 
           "&uom=" . urlencode($uom));
    exit;
}

// Query for lot details
$lotDetails = [];
$historyRecords = [];
if (!empty($lot)) {
    // Get latest lot data for the specific lot and customer_po combination
    $sql = "SELECT * FROM lot_history 
            WHERE lot_number = ? 
            AND customer_po = ? 
            ORDER BY updated_at DESC 
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $lot, $customer_po);
    $stmt->execute();
    $result = $stmt->get_result();
    $lotDetails = $result->fetch_assoc();
    $stmt->close();
    
    // Get history records (unchanged - shows all records for lot regardless of PO)
    $historySql = "SELECT * FROM lot_history WHERE lot_number = ? ORDER BY updated_at DESC";
    $historyStmt = $conn->prepare($historySql);
    $historyStmt->bind_param("s", $lot);
    $historyStmt->execute();
    $historyResult = $historyStmt->get_result();
    while ($row = $historyResult->fetch_assoc()) {
        $historyRecords[] = $row;
    }
    $historyStmt->close();
}

// Close connection
$conn->close();

// Set default values if not found
if (empty($lotDetails)) {
    $lotDetails = [
        'lot_number' => $lot,
        'product_name' => !empty($product_name) ? $product_name : 'N/A',
        'customer_po' => !empty($customer_po) ? $customer_po : 'N/A',
        'qty' => !empty($qty) ? $qty : '0',
        'uom' => !empty($uom) ? $uom : 'N/A',
        'status' => '', // Empty status for new lots
        'picture1' => '',
        'picture2' => '',
        'picture3' => '',
        'remarks' => '' // Empty remarks by default
    ];
}

// Create form data using URL parameters
$formData = [
    'lot_number' => $lot,
    'product_name' => $product_name,
    'customer_po' => $customer_po,
    'qty' => $qty,
    'uom' => $uom,
    'status' => $lotDetails['status'] ?? '',
    'remarks' => $lotDetails['remarks'] ?? '',
    'picture1' => $lotDetails['picture1'] ?? '',
    'picture2' => $lotDetails['picture2'] ?? '',
    'picture3' => $lotDetails['picture3'] ?? ''
];

// Reset status and images after successful submission
if (isset($_SESSION['reset_form'])) {
    $formData['status'] = '';
    $formData['picture1'] = '';
    $formData['picture2'] = '';
    $formData['picture3'] = '';
    unset($_SESSION['reset_form']);
}

// Determine status color if status exists
$statusColor = '';
if (!empty($formData['status'])) {
    switch ($formData['status']) {
        case 'Accepted':
            $statusColor = '#27ae60';
            break;
        case 'On Hold':
            $statusColor = '#f39c12';
            break;
        case 'Rejected':
            $statusColor = '#e74c3c';
            break;
        default:
            $statusColor = '#3498db';
    }
}

// Updated to match index.php's session structure
$currentUser = isset($_SESSION['user']['full_name']) ? $_SESSION['user']['full_name'] : 'Unknown User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lot Details: <?php echo htmlspecialchars($lot); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ======================================================== */
        /* GLOBAL STYLES
        /* ======================================================== */
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --success: #27ae60;
            --danger: #e74c3c;
            --warning: #f39c12;
            --light: #ecf0f1;
            --dark: #34495e;
            --glass: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --ocean: #1a73e8;
            --air: #34a853;
            --lot-bg: #1a2a3a;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        html, body {
            height: 100%;
        }
        
        body {
            background: linear-gradient(135deg, #0f1c2a, #1a2a3a);
            color: #f5f5f5;
            line-height: 1.6;
            padding: 0;
            display: flex;
            flex-direction: column;
        }
        
        .container {
            max-width: 100%;
            width: 100%;
            flex: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
        }
        
        /* ======================================================== */
        /* HEADER SECTION */
        /* ======================================================== */
        header {
            background: var(--glass);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 15px 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            border: 1px solid var(--glass-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo i {
            font-size: 2.2rem;
            color: var(--secondary);
        }
        
        .logo h1 {
            font-size: 1.6rem;
            color: white;
            font-weight: 600;
        }
        
        .back-btn {
            background: var(--dark);
            padding: 8px 16px;
            border-radius: 20px;
            color: white;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.95rem;
            text-decoration: none;
            transition: all 0.3s;
            margin-left: 20px; /* Added spacing */
        }
        
        .back-btn:hover {
            background: var(--primary);
            transform: translateY(-2px);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.95rem;
            color: rgba(255, 255, 255, 0.8);
            margin-right: 20px; /* Added spacing */
        }
        
        .user-info i {
            color: var(--secondary);
        }
        
        .header-right {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        /* ======================================================== */
        /* LOT DETAILS CARD */
        /* ======================================================== */
        .lot-card {
            background: linear-gradient(145deg, rgba(26, 42, 58, 0.9), rgba(21, 33, 46, 0.95));
            backdrop-filter: blur(12px);
            border-radius: 20px;
            box-shadow: 
                0 15px 35px rgba(0, 0, 0, 0.25),
                0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            border: 1px solid rgba(52, 152, 219, 0.15);
            position: relative;
            z-index: 1;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .lot-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #3498db, #2ecc71, #e74c3c, #f39c12);
            z-index: 2;
        }
        
        .lot-header {
            padding: 25px 30px;
            text-align: center;
            background: rgba(0, 0, 0, 0.2);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .lot-number {
            font-size: 2.8rem;
            font-weight: 800;
            color: white;
            margin-bottom: 10px;
            letter-spacing: 1px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            background: linear-gradient(135deg, #3498db, #8e44ad);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .lot-subtitle {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.7);
            font-weight: 500;
        }
        
        .lot-body {
            padding: 30px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .detail-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }
        
        .detail-row {
            display: flex;
            flex-direction: column;
            padding: 18px 20px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .detail-row:hover {
            background: rgba(52, 152, 219, 0.08);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .detail-row::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 4px;
            background: var(--secondary);
        }
        
        .detail-label {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.65);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }
        
        .detail-value {
            font-size: 1.25rem;
            font-weight: 600;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .status-indicator {
            display: inline-flex;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            align-items: center;
            gap: 5px;
        }
        
        /* Status dropdown styles */
        .status-select {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            color: white;
            padding: 8px 15px;
            width: 100%;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .status-select:focus {
            outline: none;
            border-color: var(--secondary);
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.3);
        }
        
        .status-option {
            padding: 8px 12px;
            background: var(--dark);
        }
        
        .status-option[value="Accepted"] {
            background: rgba(39, 174, 96, 0.2);
            color: #27ae60;
        }
        
        .status-option[value="On Hold"] {
            background: rgba(243, 156, 18, 0.2);
            color: #f39c12;
        }
        
        .status-option[value="Rejected"] {
            background: rgba(231, 76, 60, 0.2);
            color: #e74c3c;
        }
        
        /* ======================================================== */
        /* IMAGE SECTION */
        /* ======================================================== */
        .image-section {
            margin-top: 25px;
        }
        
        .image-row {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 15px;
        }
        
        .image-upload {
            flex: 1;
            min-width: 200px;
        }
        
        .image-preview-container {
            position: relative;
            width: 100%;
            margin-bottom: 10px;
        }
        
        .image-preview {
            width: 100%;
            height: 180px;
            border-radius: 12px;
            object-fit: cover;
            border: 2px solid rgba(255, 255, 255, 0.1);
            background: rgba(255, 255, 255, 0.05);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: rgba(255, 255, 255, 0.4);
            overflow: hidden;
        }
        
        .image-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .image-placeholder {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100%;
        }
        
        .image-placeholder i {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .camera-btn {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: rgba(52, 152, 219, 0.8);
            border-radius: 50%;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 10;
            border: none;
            color: white;
            font-size: 1.1rem;
            transition: all 0.3s;
        }
        
        .camera-btn:hover {
            background: var(--secondary);
            transform: scale(1.1);
        }
        
        .image-upload input[type="file"] {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 8px;
            color: rgba(255, 255, 255, 0.7);
            transition: all 0.3s;
        }
        
        .image-upload input[type="file"]:hover {
            border-color: var(--secondary);
        }
        
        /* ======================================================== */
        /* REMARKS SECTION */
        /* ======================================================== */
        .remarks-section {
            margin-top: 20px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.15);
            border-radius: 12px;
        }
        
        .remarks-label {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--secondary);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .remarks-content {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            padding: 15px;
            border-left: 3px solid var(--secondary);
            font-size: 1.05rem;
            line-height: 1.7;
            margin-bottom: 15px;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
        }
        
        .remarks-content.collapsed {
            max-height: 4.5em; /* Show approx 3 lines */
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .toggle-remarks {
            background: rgba(52, 152, 219, 0.1);
            border: 1px solid rgba(52, 152, 219, 0.3);
            color: var(--secondary);
            padding: 5px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s;
        }
        
        .toggle-remarks:hover {
            background: rgba(52, 152, 219, 0.2);
        }
        
        .remarks-textarea {
            width: 100%;
            min-height: 100px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 15px;
            color: white;
            font-size: 1rem;
            resize: vertical;
            transition: all 0.3s;
        }
        
        .remarks-textarea:focus {
            outline: none;
            border-color: var(--secondary);
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.3);
        }
        
        /* ======================================================== */
        /* SUBMIT BUTTON */
        /* ======================================================== */
        .submit-section {
            margin-top: 25px;
            text-align: center;
        }
        
        .submit-btn {
            background: var(--success);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .submit-btn:hover {
            background: #219653;
            transform: translateY(-2px);
            box-shadow: 0 7px 14px rgba(0, 0, 0, 0.2);
        }
        
        .submit-btn:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        /* ======================================================== */
        /* PREVIOUS RECORDS SECTION */
        /* ======================================================== */
        .previous-records-section {
            margin-top: 40px;
            background: rgba(0, 0, 0, 0.15);
            border-radius: 15px;
            padding: 20px;
        }
        
        .previous-records-section h2 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            color: var(--secondary);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .previous-records-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .previous-records-table th, .previous-records-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .previous-records-table th {
            background: rgba(0, 0, 0, 0.2);
            color: var(--secondary);
            font-weight: 600;
        }
        
        .previous-records-table tr {
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .previous-records-table tr:hover {
            background: rgba(52, 152, 219, 0.1);
        }
        
        /* ======================================================== */
        /* POPUP MODAL */
        /* ======================================================== */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }
        
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        .modal-content {
            background: linear-gradient(145deg, rgba(26, 42, 58, 0.95), rgba(21, 33, 46, 0.98));
            border-radius: 15px;
            width: 90%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
            padding: 30px;
            position: relative;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(52, 152, 219, 0.2);
            transform: translateY(20px);
            transition: all 0.3s;
        }
        
        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .modal-title {
            font-size: 1.5rem;
            color: white;
            font-weight: 600;
        }
        
        .modal-close {
            background: var(--danger);
            border: none;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .modal-close:hover {
            background: #c0392b;
            transform: rotate(90deg);
        }
        
        .modal-body {
            margin-bottom: 20px;
        }
        
        .modal-images {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 20px;
        }
        
        .modal-image {
            flex: 1;
            min-width: 200px;
            height: 200px;
            border-radius: 10px;
            overflow: hidden;
            background: rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-image img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        
        /* MODAL IMAGE PLACEHOLDER STYLES */
        .modal-image .image-placeholder {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100%;
            color: rgba(255, 255, 255, 0.4);
            background: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
        }
        
        .modal-image .image-placeholder i {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        /* ======================================================== */
        /* CONFIRMATION CHECKBOX */
        /* ======================================================== */
        .confirmation-checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 20px 0;
            padding: 10px;
            background: rgba(39, 174, 96, 0.1);
            border: 1px solid rgba(39, 174, 96, 0.3);
            color: var(--secondary);
            padding: 5px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s;
        }
        
        .confirmation-checkbox input {
            width: 18px;
            height: 18px;
        }
        
        .confirmation-checkbox label {
            font-size: 0.95rem;
            color: rgba(255, 255, 255, 0.8);
        }
        
        /* ======================================================== */
        /* FOOTER */
        /* ======================================================== */
        footer {
            text-align: center;
            margin-top: 20px;
            color: rgba(255, 255, 255, 0.4);
            font-size: 0.85rem;
            padding: 15px;
        }
        
        /* ======================================================== */
        /* RESPONSIVE DESIGN */
        /* ======================================================== */
        @media (min-width: 768px) {
            .detail-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .lot-number {
                font-size: 3.2rem;
            }
            
            .image-row {
                flex-wrap: nowrap;
            }
        }
        
        @media (max-width: 480px) {
            .lot-number {
                font-size: 2.3rem;
            }
            
            .lot-header {
                padding: 20px 15px;
            }
            
            .lot-body {
                padding: 20px;
            }
            
            .detail-value {
                font-size: 1.1rem;
            }
            
            .image-row {
                flex-direction: column;
            }
            
            header {
                flex-direction: column;
                gap: 15px;
            }
            
            .header-right {
                width: 100%;
                justify-content: space-between;
            }
            
            .modal-content {
                width: 95%;
                padding: 20px;
            }
        }
        
        /* Decorative elements */
        .decoration {
            position: fixed;
            z-index: -1;
            opacity: 0.1;
        }
        
        .decoration.circle {
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background: var(--secondary);
            top: -150px;
            right: -150px;
        }
        
        .decoration.square {
            width: 200px;
            height: 200px;
            background: var(--success);
            bottom: -100px;
            left: -100px;
            transform: rotate(45deg);
        }
        
        /* ======================================================== */
        /* ERROR MESSAGE STYLING */
        /* ======================================================== */
        .error-message {
            background-color: #e74c3c;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
            animation: fadeIn 0.5s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* ======================================================== */
        /* IMAGE THUMBNAILS */
        /* ======================================================== */
        .image-thumb {
            width: 40px;
            height: 40px;
            border-radius: 4px;
            object-fit: cover;
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .image-thumb:hover {
            transform: scale(1.8);
            z-index: 100;
            position: relative;
        }
        
        .image-link {
            display: inline-block;
            padding: 4px 8px;
            background: rgba(52, 152, 219, 0.2);
            border-radius: 4px;
            color: var(--secondary);
            font-size: 0.8rem;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .image-link:hover {
            background: rgba(52, 152, 219, 0.3);
        }

        /* ======================================================== */
        /* IMAGE PREVIEW MODAL STYLES */
        /* ======================================================== */
        #imageModal .modal-body {
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: auto;
            padding: 20px;
        }

        #imagePreviewContainer {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100%;
            background: transparent;
            border-radius: 0;
            overflow: visible;
        }

        #fullImagePreview {
            max-width: 90vw;
            max-height: 90vh;
            object-fit: contain;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
    <div class="decoration circle"></div>
    <div class="decoration square"></div>
    
    <div class="container">
        <!-- ======================================================== -->
        <!-- HEADER SECTION -->
        <!-- ======================================================== -->
        <header>
            <div class="logo">
                <i class="fas fa-database"></i>
                <h1>Lot Details</h1>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <i class="fas fa-user-circle"></i>
                    <?php echo htmlspecialchars($currentUser); ?>
                </div>
                <a href="index.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </header>
        
        <!-- Display error message if exists -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?php echo $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <!-- ======================================================== -->
        <!-- LOT DETAILS FORM -->
        <!-- ======================================================== -->
        <form method="POST" action="lot_details.php" enctype="multipart/form-data">
            <!-- Hidden fields to save data -->
            <input type="hidden" name="lot" value="<?php echo htmlspecialchars($formData['lot_number']); ?>">
            <input type="hidden" name="product_name" value="<?php echo htmlspecialchars($formData['product_name']); ?>">
            <input type="hidden" name="customer_po" value="<?php echo htmlspecialchars($formData['customer_po']); ?>">
            <input type="hidden" name="qty" value="<?php echo htmlspecialchars($formData['qty']); ?>">
            <input type="hidden" name="uom" value="<?php echo htmlspecialchars($formData['uom']); ?>">
            
            <div class="lot-card">
                <div class="lot-header">
                    <div class="lot-number"><?php echo htmlspecialchars($formData['lot_number']); ?></div>
                    <div class="lot-subtitle">Detailed Information</div>
                </div>
                
                <div class="lot-body">
                    <div class="detail-grid">
                        <div class="detail-row">
                            <span class="detail-label">Product Name</span>
                            <span class="detail-value">
                                <i class="fas fa-cube"></i>
                                <?php echo htmlspecialchars($formData['product_name']); ?>
                            </span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Customer PO#</span>
                            <span class="detail-value">
                                <i class="fas fa-barcode"></i>
                                <?php echo htmlspecialchars($formData['customer_po']); ?>
                            </span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Quantity</span>
                            <span class="detail-value">
                                <i class="fas fa-weight-hanging"></i>
                                <?php echo htmlspecialchars($formData['qty']); ?> 
                                <span style="opacity: 0.7; font-size: 0.9em;">(<?php echo htmlspecialchars($formData['uom']); ?>)</span>
                            </span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Current Status</span>
                            <div class="detail-value">
                                <?php if (!empty($formData['status'])): ?>
                                    <span class="status-indicator" style="background-color: <?php echo $statusColor; ?>20; color: <?php echo $statusColor; ?>; border: 1px solid <?php echo $statusColor; ?>">
                                        <i class="fas fa-circle" style="font-size: 0.7em; color: <?php echo $statusColor; ?>"></i>
                                        <?php echo htmlspecialchars($formData['status']); ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: rgba(255,255,255,0.5);">No status set</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">New Status</span>
                            <div class="detail-value">
                                <select class="status-select" name="status" required>
                                    <option value="" disabled selected>Select New Status</option>
                                    <option class="status-option" value="Accepted">Accepted</option>
                                    <option class="status-option" value="On Hold">On Hold</option>
                                    <option class="status-option" value="Rejected">Rejected</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Status change confirmation -->
                    <div class="confirmation-checkbox">
                        <input type="checkbox" id="confirm_status_change" name="confirm_status_change" value="yes" required>
                        <label for="confirm_status_change">I confirm that I want to change the status of this lot</label>
                    </div>
                    
                    <!-- ======================================================== -->
                    <!-- REMARKS SECTION -->
                    <!-- ======================================================== -->
                    <div class="remarks-section">
                        <div class="remarks-label">
                            <i class="fas fa-comment-alt"></i> Remarks & Notes
                        </div>
                        <?php if (!empty($formData['remarks'])): ?>
                            <div class="remarks-content collapsed" id="remarksContent">
                                <?php echo htmlspecialchars($formData['remarks']); ?>
                            </div>
                            <button type="button" class="toggle-remarks" id="toggleRemarks">
                                <i class="fas fa-chevron-down"></i> Show More
                            </button>
                        <?php endif; ?>
                        <textarea class="remarks-textarea" name="remarks" placeholder="Enter new remark here..."></textarea>
                    </div>
                    
                    <!-- ======================================================== -->
                    <!-- IMAGE SECTION -->
                    <!-- ======================================================== -->
                    <div class="image-section">
                        <div class="remarks-label">
                            <i class="fas fa-images"></i> Product Images
                        </div>
                        <div class="image-row">
                            <div class="image-upload">
                                <div class="image-preview-container">
                                    <div class="image-preview" id="preview1">
                                        <?php if (!empty($formData['picture1'])): 
                                            $mime = 'image/jpeg'; // Default to jpeg if we can't detect
                                            if (function_exists('finfo_open')) {
                                                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                                                $mime = finfo_buffer($finfo, $formData['picture1']);
                                            }
                                            $base64 = base64_encode($formData['picture1']);
                                        ?>
                                            <img src="data:<?php echo $mime; ?>;base64,<?php echo $base64; ?>" alt="Image 1">
                                        <?php else: ?>
                                            <div class="image-placeholder">
                                                <i class="fas fa-image"></i>
                                                <div>Image 1</div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <button type="button" class="camera-btn" onclick="openCamera(1)">
                                        <i class="fas fa-camera"></i>
                                    </button>
                                </div>
                                <input type="file" name="image1" accept="image/*" onchange="previewImage(event, 1)" capture="camera">
                            </div>
                            <div class="image-upload">
                                <div class="image-preview-container">
                                    <div class="image-preview" id="preview2">
                                        <?php if (!empty($formData['picture2'])): 
                                            $mime = 'image/jpeg';
                                            if (function_exists('finfo_open')) {
                                                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                                                $mime = finfo_buffer($finfo, $formData['picture2']);
                                            }
                                            $base64 = base64_encode($formData['picture2']);
                                        ?>
                                            <img src="data:<?php echo $mime; ?>;base64,<?php echo $base64; ?>" alt="Image 2">
                                        <?php else: ?>
                                            <div class="image-placeholder">
                                                <i class="fas fa-image"></i>
                                                <div>Image 2</div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <button type="button" class="camera-btn" onclick="openCamera(2)">
                                        <i class="fas fa-camera"></i>
                                    </button>
                                </div>
                                <input type="file" name="image2" accept="image/*" onchange="previewImage(event, 2)" capture="camera">
                            </div>
                            <div class="image-upload">
                                <div class="image-preview-container">
                                    <div class="image-preview" id="preview3">
                                        <?php if (!empty($formData['picture3'])): 
                                            $mime = 'image/jpeg';
                                            if (function_exists('finfo_open')) {
                                                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                                                $mime = finfo_buffer($finfo, $formData['picture3']);
                                            }
                                            $base64 = base64_encode($formData['picture3']);
                                        ?>
                                            <img src="data:<?php echo $mime; ?>;base64,<?php echo $base64; ?>" alt="Image 3">
                                        <?php else: ?>
                                            <div class="image-placeholder">
                                                <i class="fas fa-image"></i>
                                                <div>Image 3</div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <button type="button" class="camera-btn" onclick="openCamera(3)">
                                        <i class="fas fa-camera"></i>
                                    </button>
                                </div>
                                <input type="file" name="image3" accept="image/*" onchange="previewImage(event, 3)" capture="camera">
                            </div>
                        </div>
                    </div>
                    
                    <!-- ======================================================== -->
                    <!-- SUBMIT BUTTON -->
                    <!-- ======================================================== -->
                    <div class="submit-section">
                        <button type="submit" class="submit-btn">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </div>
                </div>
            </div>
        </form>
        
        <!-- ======================================================== -->
        <!-- PREVIOUS RECORDS SECTION -->
        <!-- ======================================================== -->
        <div class="previous-records-section">
            <h2><i class="fas fa-history"></i> Previous Records</h2>
            <table class="previous-records-table">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>PO #</th>
                        <th>Status</th>
                        <th>User</th>
                        <th>Remarks Notes</th>
                        <th>Image 1</th>
                        <th>Image 2</th>
                        <th>Image 3</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($historyRecords)): ?>
                        <?php foreach ($historyRecords as $record): ?>
                            <tr onclick="showRecordDetails(<?php echo $record['id']; ?>)">
                                <td><?php echo htmlspecialchars($record['updated_at']); ?></td>
                                <td><?php echo htmlspecialchars($record['customer_po']); ?></td>
                                <td>
                                    <?php 
                                    $statusColor = '';
                                    switch ($record['status']) {
                                        case 'Accepted':
                                            $statusColor = '#27ae60';
                                            break;
                                        case 'On Hold':
                                            $statusColor = '#f39c12';
                                            break;
                                        case 'Rejected':
                                            $statusColor = '#e74c3c';
                                            break;
                                        default:
                                            $statusColor = '#3498db';
                                    }
                                    ?>
                                    <span class="status-indicator" style="background-color: <?php echo $statusColor; ?>20; color: <?php echo $statusColor; ?>; border: 1px solid <?php echo $statusColor; ?>">
                                        <i class="fas fa-circle" style="font-size: 0.7em; color: <?php echo $statusColor; ?>"></i>
                                        <?php echo htmlspecialchars($record['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($record['updated_by']); ?></td>
                                <td>
                                    <?php
                                    // Extract only the user's note from remarks
                                    $pattern = "/^\[.*?\] .*?: Status changed to '.*?'\. /";
                                    $note = preg_replace($pattern, '', $record['remarks']);
                                    // If the pattern didn't remove anything, try alternative method
                                    if ($note === $record['remarks']) {
                                        // Fallback: take everything after the first period and space
                                        $pos = strpos($record['remarks'], '. ');
                                        if ($pos !== false) {
                                            $note = substr($record['remarks'], $pos + 2);
                                        } else {
                                            $note = $record['remarks'];
                                        }
                                    }
                                    echo htmlspecialchars(mb_strimwidth($note, 0, 50, '...'));
                                    ?>
                                </td>
                                <!-- Image columns -->
                                <?php for ($i = 1; $i <= 3; $i++): ?>
                                    <td>
                                        <?php if (!empty($record["picture$i"])): ?>
                                            <a href="#" onclick="showImagePreview('<?php echo base64_encode($record["picture$i"]); ?>', <?php echo $i; ?>)" class="image-link">
                                                View Image
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                <?php endfor; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8">No previous records available</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <footer>
            CPO Management System &copy; <?php echo date('Y'); ?> | Lot Details
        </footer>
    </div>
    
    <!-- ======================================================== -->
    <!-- RECORD DETAILS MODAL -->
    <!-- ======================================================== -->
    <div class="modal-overlay" id="recordModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Record Details</h3>
                <button class="modal-close" onclick="closeModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Content will be inserted here by JavaScript -->
            </div>
        </div>
    </div>
    
    <!-- ======================================================== -->
    <!-- IMAGE PREVIEW MODAL -->
    <!-- ======================================================== -->
    <div class="modal-overlay" id="imageModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Image Preview</h3>
                <button class="modal-close" onclick="closeImageModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div id="imagePreviewContainer">
                    <img id="fullImagePreview">
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Add animation to elements when page loads
        document.addEventListener('DOMContentLoaded', function() {
            const detailRows = document.querySelectorAll('.detail-row');
            detailRows.forEach((row, index) => {
                setTimeout(() => {
                    row.style.opacity = '0';
                    row.style.transform = 'translateY(20px)';
                    row.style.transition = 'all 0.5s ease-out';
                    
                    setTimeout(() => {
                        row.style.opacity = '1';
                        row.style.transform = 'translateY(0)';
                    }, 50);
                }, 100 * index);
            });
            
            // Animate the lot number
            const lotNumber = document.querySelector('.lot-number');
            if (lotNumber) {
                setTimeout(() => {
                    lotNumber.style.opacity = '0';
                    lotNumber.style.transform = 'scale(0.8)';
                    lotNumber.style.transition = 'all 0.5s ease-out';
                    
                    setTimeout(() => {
                        lotNumber.style.opacity = '1';
                        lotNumber.style.transform = 'scale(1)';
                    }, 50);
                }, 100);
            }
            
            // Update status indicator when dropdown changes
            const statusSelect = document.querySelector('.status-select');
            if (statusSelect) {
                // Set initial color based on selected value
                function updateStatusColor() {
                    const value = statusSelect.value;
                    let color = '#3498db';
                    
                    if (value === 'Accepted') color = '#27ae60';
                    else if (value === 'On Hold') color = '#f39c12';
                    else if (value === 'Rejected') color = '#e74c3c';
                    
                    statusSelect.style.backgroundColor = color + '20';
                    statusSelect.style.color = color;
                    statusSelect.style.borderColor = color;
                }
                
                statusSelect.addEventListener('change', updateStatusColor);
                updateStatusColor(); // Initialize color
            }
            
            // Remarks expand/collapse functionality
            const remarksContent = document.getElementById('remarksContent');
            const toggleRemarks = document.getElementById('toggleRemarks');
            
            if (remarksContent && toggleRemarks) {
                // Check if content is truncated
                if (remarksContent.scrollHeight > remarksContent.clientHeight) {
                    toggleRemarks.style.display = 'inline-flex';
                }
                
                toggleRemarks.addEventListener('click', function() {
                    remarksContent.classList.toggle('collapsed');
                    
                    if (remarksContent.classList.contains('collapsed')) {
                        this.innerHTML = '<i class="fas fa-chevron-down"></i> Show More';
                    } else {
                        this.innerHTML = '<i class="fas fa-chevron-up"></i> Show Less';
                    }
                });
            }
        });
        
        // Image preview and camera functions
        function previewImage(event, imageNumber) {
            const input = event.target;
            const preview = document.getElementById(`preview${imageNumber}`);
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.innerHTML = `<img src="${e.target.result}" alt="Image ${imageNumber}">`;
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        function openCamera(imageNumber) {
            // Trigger the file input with camera capture
            const fileInput = document.querySelector(`input[name="image${imageNumber}"]`);
            fileInput.click();
        }
        
        // Add hover effect to image placeholders
        const imagePlaceholders = document.querySelectorAll('.image-preview');
        imagePlaceholders.forEach(placeholder => {
            placeholder.addEventListener('mouseenter', function() {
                this.style.borderColor = 'var(--secondary)';
                this.style.backgroundColor = 'rgba(52, 152, 219, 0.1)';
            });
            
            placeholder.addEventListener('mouseleave', function() {
                this.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                this.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
            });
        });
        
        // Modal functions for showing record details
        function showRecordDetails(recordId) {
            fetch(`get_record_details.php?id=${recordId}`)
                .then(response => response.json())
                .then(record => {
                    const modal = document.getElementById('recordModal');
                    const modalBody = document.getElementById('modalBody');
                    
                    // Get status color
                    let statusColor = '#3498db';
                    switch (record.status) {
                        case 'Accepted':
                            statusColor = '#27ae60';
                            break;
                        case 'On Hold':
                            statusColor = '#f39c12';
                            break;
                        case 'Rejected':
                            statusColor = '#e74c3c';
                            break;
                    }
                    
                    // Create HTML for the modal content
                    let html = `
                        <div class="detail-grid">
                            <div class="detail-row">
                                <span class="detail-label">Date & Time</span>
                                <span class="detail-value">${record.updated_at}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Lot Number</span>
                                <span class="detail-value">${record.lot_number}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Product Name</span>
                                <span class="detail-value">${record.product_name}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Customer PO</span>
                                <span class="detail-value">${record.customer_po}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Quantity</span>
                                <span class="detail-value">${record.qty} ${record.uom}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Status</span>
                                <span class="detail-value">
                                    <span class="status-indicator" style="background-color: ${statusColor}20; color: ${statusColor}; border: 1px solid ${statusColor}">
                                        <i class="fas fa-circle" style="font-size: 0.7em; color: ${statusColor}"></i>
                                        ${record.status}
                                    </span>
                                </span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Updated By</span>
                                <span class="detail-value">${record.updated_by}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Remarks</span>
                                <span class="detail-value">${record.remarks.replace(/\n/g, '<br>')}</span>
                            </div>
                        </div>
                    `;
                    
                    modalBody.innerHTML = html;
                    modal.classList.add('active');
                    document.body.style.overflow = 'hidden';
                })
                .catch(error => {
                    console.error('Error fetching record details:', error);
                    alert('Error loading record details');
                });
        }
        
        function closeModal() {
            const modal = document.getElementById('recordModal');
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
        
        // Close modal when clicking outside content
        document.getElementById('recordModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
        
        // Close modal with ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
        
        // Image preview functions
        function showImagePreview(base64Data, imageNumber) {
            const imageModal = document.getElementById('imageModal');
            const imgElement = document.getElementById('fullImagePreview');
            
            // Create a blob from base64 data
            const byteCharacters = atob(base64Data);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], {type: 'image/jpeg'});
            
            // Create object URL and set as image source
            imgElement.src = URL.createObjectURL(blob);
            imgElement.alt = `Image ${imageNumber}`;
            
            imageModal.classList.add('active');
            document.body.style.overflow = 'hidden';
            
            // Remove previous event listener to prevent duplicates
            imgElement.onload = function() {
                URL.revokeObjectURL(this.src); // Free memory after image loads
            };
        }

        function closeImageModal() {
            const imageModal = document.getElementById('imageModal');
            imageModal.classList.remove('active');
            document.body.style.overflow = '';
            
            // Clean up object URL
            const imgElement = document.getElementById('fullImagePreview');
            if (imgElement.src.startsWith('blob:')) {
                URL.revokeObjectURL(imgElement.src);
            }
            imgElement.src = '';
        }

        // Close image modal when clicking outside content
        document.getElementById('imageModal').addEventListener('click', function(e) {
            if (e.target === this || e.target.classList.contains('modal-close')) {
                closeImageModal();
            }
        });
    </script>
</body>
</html>